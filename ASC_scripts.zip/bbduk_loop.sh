#!/bin/sh
#source /opt/asn/etc/asn-bash-profiles-special/modules.sh
module load bbmap
mkdir -p adapter_trimmed
mkdir -p quality_trimmed
raw_data="./raw_data"

# Loop through each pair of FASTQ files
for R1 in $raw_data/*_R1_*.fastq.gz
do
    R2=${R1/_R1_/_R2_}

    # Extract base file name without the extension and path
    BASE1=$(basename ${R1%.fastq.gz})
    BASE2=$(basename ${R2%.fastq.gz})

    # Define output file names for adapter trimmed files
    OUT1=adapter_trimmed/${BASE1}.adaptertrim.fastq
    OUT2=adapter_trimmed/${BASE2}.adaptertrim.fastq
    
    # Define output file names for quality trimmed files
    CLEAN_OUT1=quality_trimmed/${BASE1}.clean.fastq
    CLEAN_OUT2=quality_trimmed/${BASE2}.clean.fastq
    
    echo "Processing $R1 and $R2 for adapter trimming..."
    bbduk.sh -Xmx1g in1=$R1 in2=$R2 out1=$OUT1 out2=$OUT2 ref=adapters.fa ktrim=r k=23 mink=11 hdist=1 tpe tbo
    
    echo "Processing $OUT1 and $OUT2 for quality trimming..."
    bbduk.sh -Xmx1g in1=$OUT1 in2=$OUT2 out1=$CLEAN_OUT1 out2=$CLEAN_OUT2 qtrim=rl trimq=30 minlen=50
    
done

echo "Trimming complete."

#!/bin/sh
# source /opt/asn/etc/asn-bash-profiles-special/modules.sh
# Loading modules
module load star

# Set the stack size to unlimited
ulimit -s unlimited

# Turn echo on so all commands are echoed in the output log
set -x

# Set variables according to the specified directories and files
ref_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.fna"
gtf_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
CLEAND="/home/aubzxk001/Cells_ARV_RNASeq_2023/adapter_and_quality_trimmed"
REFD="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/star/star_index"
MAPD="/home/aubzxk001/Cells_ARV_RNASeq_2023/star_results"

# Make directories if they do not exist
mkdir -p $MAPD

# Assuming your files are correctly gzipped, if not, uncomment the next line
# gzip $CLEAND/*.fq

# Move into the directory containing cleaned reads
cd $CLEAND

# Create a list of sample names
ls | grep ".fastq" | cut -d "_" -f 1 | sort | uniq > list

# Copy the list of sample names to the output directory
cp list $MAPD/

# Move into the output directory
cd $MAPD

# Create a directory for STAR alignments if not exists
mkdir -p alignments_STAR

# Create a for loop to run STAR on each sample
while read i; do
    STAR --genomeDir $REFD \
         --readFilesIn "$CLEAND/${i}_R1.fastq" "$CLEAND/${i}_R2.fastq" \
         --runThreadN 30 \
         --outSAMtype BAM SortedByCoordinate \
         --quantMode GeneCounts \
         --outFileNamePrefix alignments_STAR/"$i"_
done < list

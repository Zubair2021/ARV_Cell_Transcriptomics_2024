#!/bin/bash
#
#  load the module
module load stringtie/2.2.1

gtf="/home/aubzxk001/Cells_ARV_RNASeq_2023/galgal_ncbi.gtf"

cd /home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/hisat2_stringtie

stringtie --merge -p 16 -G $gtf -o stringtie_hisat2_merged.gtf mergelist.txt

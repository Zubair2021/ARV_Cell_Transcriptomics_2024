#!/bin/bash

module load hisat2
# exec >log_test_align_hisat2.txt 2>&1

mkdir -p hisat2/hisat2_results/sam_files

# set variables
input_dir="./adapter_and_quality_trimmed"
ref_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome"
ref_file="GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.fna"
index_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/galgal_index"
gtf_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
sam_dir="hisat2/hisat2_results/sam_files"
index_name="galgal_index"

exec >> align_hisat2.log 2>&1

for fastq1 in $input_dir/*_R1.fastq
do
   base=$(basename $fastq1 _R1.fastq)
   
   echo "Processing sample ${base}."
   
   fastq1=${base}_R1.fastq
   echo $fastq1
   fastq2=${base}_R2.fastq
   echo $fastq2

   hisat2 -p 16 --dta -x $index_dir/$index_name -1 $input_dir/$fastq1 -2 $input_dir/$fastq2 -S $sam_dir/${base}.sam

done

echo "hisat align done"


# #for creating index
# hisat2_extract_splice_sites.py $gtf_file >$index_dir/galgal.ss
# hisat2_extract_exons.py  $gtf_file >$index_dir/galgal.ex

# hisat2-build -p 16 --ss $index_dir/galgal.ss --exon $index_dir/galgal.ex $ref_dir/$ref_file $index_dir/$index_name


# # build hisat2 index - 300gb gb memory and 32 cores
# hisat2-build -p 16 $ref_dir/$ref_file $index_dir/index_no_ss_ex

# # check if the index files have been successfully built
# for i in 1 2 3 4 5 6 7 8
# do
#     if [ ! -f "$index_dir/$index_name.$i.ht2" ]; then
#         echo "Index file $index_dir/$index_name.$i.ht2 was not found. Index building may have failed."
#         exit 1
#     fi
# done

# echo "Index files have been successfully built."
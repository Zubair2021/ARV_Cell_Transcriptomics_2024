#!/bin/sh

# Loading modules
module load star

# Set the stack size to unlimited
ulimit -s unlimited

# Turn echo on so all commands are echoed in the output log
set -x

# make directories
mkdir -p star

# Set variables
ref_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.fna"
gtf_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
WD=.
CLEAND="/home/aubzxk001/Cells_ARV_RNASeq_2023/adapter_and_quality_trimmed"
REFD="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data"
INDEXD=./star/star_index # Directory for the STAR index

# Making directories
mkdir -p $MAPD

cd $REFD

STAR --runThreadN 30 \
    --runMode genomeGenerate \
    --genomeDir $INDEXD \
    --genomeFastaFiles $ref_file \
    --sjdbGTFfile $gtf_file \
    --sjdbOverhang 150 \
    --limitGenomeGenerateRAM 120000000000

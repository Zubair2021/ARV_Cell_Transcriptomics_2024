#!/bin/bash
module load samtools
module load htseq

exec >> log.final_htseq_counts.txt 2>&1

# Path to your GTF file
GTF_FILE="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
SAM_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/sam_files"
COUNTS_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/HTSeq_counts"

# Output counts directories
mkdir -p "$COUNTS_DIR"

# Loop over all SAM files in the directory
for SAM_FILE in "$SAM_DIR"/*.sam
do
    # Extract the base name for use in output files
    BASE_NAME=$(basename "$SAM_FILE" .sam)
    echo "Processing $BASE_NAME"

    # Output counts file name
    COUNTS_FILE="${BASE_NAME}_counts.tsv"
    samtools view -@ 30 -Sb $SAM_FILE | samtools sort -@ 30 -m 1G | python -m HTSeq.scripts.count -s no - $GTF_FILE > $COUNTS_DIR/$COUNTS_FILE

done
#!/bin/bash
module load samtools
module load stringtie/2.2.1
module load gcc
module load anaconda/3-2022.05

exec >> log.feature_counts.txt 2>&1

# Path to your GTF file
GTF_FILE="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
SAM_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/sam_files"
# BAM_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/bam_files"
SORTED_BAM_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/sorted_bam_files"
COUNTS_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/feature_counts"

# Check if the GTF file exists
if [ -f $GTF_FILE ]; then
    echo "The GTF file exists."
else
    echo "The GTF file does not exist or the path is incorrect."
fi

# Check if the sam_directory exists
if [ -d $SAM_DIR ]; then
    echo "The sam_directory exists."
else
    echo "The sam_directory does not exist or the path is incorrect."
fi

# Output bam and feature counts directories
# mkdir -p "$BAM_DIR"
mkdir -p "$SORTED_BAM_DIR"
mkdir -p "$COUNTS_DIR"

# Loop over all SAM files in the directory
for SAM_FILE in "$SAM_DIR"/*.sam
do
    # Extract the base name for use in output files
    BASE_NAME=$(basename "$SAM_FILE" .sam)
    # Output BAM file name
    # BAM_FILE="${BASE_NAME}.bam"

    # Sorted BAM file name
    SORTED_BAM_FILE="${BASE_NAME}_sorted.bam"

    # Output counts file name
    COUNTS_FILE="${BASE_NAME}_counts.tsv"

    # # Convert SAM to BAM
    # samtools view -Sb $SAM_FILE | samtools sort $BAM_DIR/$BAM_FILE -o $SORTED_BAM_DIR/$SORTED_BAM_FILE

    samtools view -@ 28 -Sb $SAM_FILE | samtools sort -@ 28 -m 1G -o $SORTED_BAM_DIR/$SORTED_BAM_FILE

    # Count reads
    featureCounts -T 28 -p -a $GTF_FILE -o $COUNTS_DIR/$COUNTS_FILE $SORTED_BAM_DIR/$SORTED_BAM_FILE

done
#!/bin/bash
module load samtools
module load anaconda/3-2022.05


exec >> log.exon_counts.txt 2>&1

# Path to your BAM files directory
BAM_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/star_results/alignments_STAR/bam_files/test_bam"

# Path to your GTF annotation file
GTF_FILE="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"

# Output directory for exon counts
OUTPUT_DIR="${BAM_DIR}/exon_counts"
mkdir -p "${OUTPUT_DIR}"

# Number of threads to use
THREADS=30

cd /home/aubzxk001/Cells_ARV_RNASeq_2023/star_results/alignments_STAR/bam_files

# Loop through each BAM file in the directory
for BAM_FILE in ${BAM_DIR}/*.bam; do
    # Extract filename without the directory and extension
    BASE_NAME=$(basename "${BAM_FILE}" .bam)
    
    # Index the BAM file with samtools (skip if index already exists)
    if [ ! -f "${BAM_FILE}.bai" ]; then
        echo "Indexing ${BAM_FILE}..."
        samtools index -@ ${THREADS} "${BAM_FILE}"
    else
        echo "Index file for ${BAM_FILE} already exists, skipping indexing."
    fi
    
    # Define output file for featureCounts
    OUTPUT_FILE="${OUTPUT_DIR}/${BASE_NAME}_exon_counts.txt"
    
    # Run featureCounts on the BAM file
    echo "Running featureCounts on ${BAM_FILE}..."
    featureCounts -a "${GTF_FILE}" \
                  -o "${OUTPUT_FILE}" \
                  -t exon \
                  -g gene_id \
                  -s 0 \
                  -T ${THREADS} \
                  "${BAM_FILE}"
done

echo "Processing completed."

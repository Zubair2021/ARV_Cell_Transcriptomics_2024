#!/bin/sh

# Assuming fastp is installed and accessible
module load fastp 

# Create directories for trimmed output
mkdir -p adapter_and_quality_trimmed

# Directory where raw FASTQ files are located
raw_data="./raw_data"

# Loop through each pair of FASTQ files
for R1 in $raw_data/*_R1_*.fastq.gz
do
    R2=${R1/_R1_/_R2_} # Identify the matching R2 file based on naming convention
    
    # Extract the base filename without path and extension for output naming
    BASE_NAME=$(basename ${R1%_R1_*.fastq.gz})
    
    # Define output file names
    OUT1="adapter_and_quality_trimmed/${BASE_NAME}_R1.fastq"
    OUT2="adapter_and_quality_trimmed/${BASE_NAME}_R2.fastq"
    
    # Define JSON and HTML report file names
    REPORT_HTML="adapter_and_quality_trimmed/${BASE_NAME}_fastp_report.html"
    
    echo "Processing $R1 and $R2 with fastp..."
    
    # Run fastp
    fastp \
        -i $R1 -I $R2 \
        -o $OUT1 -O $OUT2 \
        -h $REPORT_HTML \
        --qualified_quality_phred 33 \
        --length_required 50 \
        --detect_adapter_for_pe

done

echo "Trimming complete."

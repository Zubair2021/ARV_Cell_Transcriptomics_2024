#!/bin/bash
module load stringtie/2.2.1
# Set the directory containing your BAM files
bam_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/sorted_bam_files"

# Set the output directory for the gtf files
output_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023//home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/ballgown"

mkdir -p "$output_dir"

# Reference annotation file used for guiding the assembly process
reference_gtf="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/hisat2_results/hisat2_stringtie/stringtie_hisat2_merged.gtf"

# Loop through BAM files in the directory
for bam_file in "$bam_dir"/*_sorted.bam; do
    # Extract the base name for the BAM file (without the path and extension)
    sample_name=$(basename "$bam_file" _sorted.bam)
    echo "Processing sample: $sample_name"
    
    # Create an output directory for the sample
    sample_output_dir="$output_dir/${sample_name}"
    mkdir -p "$sample_output_dir"
    
    Run stringtie with the options provided
    stringtie -e -B -p 32 -G "$reference_gtf" -o "${sample_output_dir}/${sample_name}.gtf" "$bam_file"
    
    echo "stringtie completed for sample $sample_name"
done

echo "All samples have been processed."


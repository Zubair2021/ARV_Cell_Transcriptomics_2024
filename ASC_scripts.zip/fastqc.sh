#!/bin/bash
#source /apps/x86-64/etc/modulefiles/fastqc/0.10.1.lua
mkdir -p fastqc_results
module load fastqc

# Directory containing the raw data
RAW_DATA_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/adapter_and_quality_trimmed"
# Directory to store the FastQC results
RESULTS_DIR="/home/aubzxk001/Cells_ARV_RNASeq_2023/fastqc_results"


# Run fastqc on each file in the background
for file in $RAW_DATA_DIR/*.fastq
do
    fastqc -t 16 -o $RESULTS_DIR $file 
done

